# Jewellery Shop Order Form

Spring Boot + MySQL backend with an HTML frontend for a jewellery shop order form.

## Project structure
```
jewellery-shop/
├── frontend/index.html          -> the order form
├── pom.xml
└── src/main/java/com/jewelleryshop/demo/
    ├── DemoApplication.java
    ├── model/JewelleryOrder.java
    ├── repository/JewelleryOrderRepository.java
    └── controller/JewelleryOrderController.java
└── src/main/resources/application.properties
```

## Run locally
1. Create the DB: `CREATE DATABASE jewellery_shop;`
2. Set your MySQL username/password as environment variables, or edit the
   defaults in `application.properties` (`MYSQLUSER`, `MYSQLPASSWORD`).
3. `mvn spring-boot:run`
4. Open `frontend/index.html` in a browser. It posts to `http://localhost:8080/api/orders`.

## Deploy to Railway
1. Push this repo to GitHub:
   ```
   git remote add origin https://github.com/YOUR_USERNAME/jewellery-shop.git
   git branch -M main
   git push -u origin main
   ```
2. On [railway.com](https://railway.com): New Project → Deploy MySQL.
3. Same project → New → GitHub Repo → select this repo.
4. In the app service's Variables tab, connect the MySQL service's variables
   (`MYSQLHOST`, `MYSQLPORT`, `MYSQLDATABASE`, `MYSQLUSER`, `MYSQLPASSWORD`) —
   `application.properties` already reads these automatically.
5. Settings → Networking → Generate Domain.
6. Update `API_URL` in `frontend/index.html` to the generated domain.
7. Submit the form, then check the `jewellery_orders` table in Railway's
   MySQL Data tab to confirm the row landed.
