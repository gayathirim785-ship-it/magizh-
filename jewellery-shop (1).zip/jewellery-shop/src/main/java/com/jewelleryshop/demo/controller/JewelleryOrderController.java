package com.jewelleryshop.demo.controller;

import com.jewelleryshop.demo.model.JewelleryOrder;
import com.jewelleryshop.demo.repository.JewelleryOrderRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*") // For local testing. Restrict this in production.
public class JewelleryOrderController {

    private final JewelleryOrderRepository repository;

    public JewelleryOrderController(JewelleryOrderRepository repository) {
        this.repository = repository;
    }

    // Handles the form submission
    @PostMapping
    public ResponseEntity<JewelleryOrder> createOrder(@Valid @RequestBody JewelleryOrder order) {
        JewelleryOrder saved = repository.save(order);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // Lets you check what's in the database
    @GetMapping
    public List<JewelleryOrder> getAllOrders() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<JewelleryOrder> getOrder(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
