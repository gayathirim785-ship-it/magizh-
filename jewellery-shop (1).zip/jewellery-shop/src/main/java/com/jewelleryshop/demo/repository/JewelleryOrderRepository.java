package com.jewelleryshop.demo.repository;

import com.jewelleryshop.demo.model.JewelleryOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JewelleryOrderRepository extends JpaRepository<JewelleryOrder, Long> {
    // JpaRepository already gives us save(), findAll(), findById(), deleteById(), etc.
}
